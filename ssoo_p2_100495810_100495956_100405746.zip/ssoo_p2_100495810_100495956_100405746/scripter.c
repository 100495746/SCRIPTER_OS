#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <signal.h>

/* CONST VARS */
const int max_line = 1024;
const int max_commands = 10;
#define max_redirections 3 //stdin, stdout, stderr
#define max_args 15

/* VARS TO BE USED FOR THE STUDENTS */
char * argvv[max_args];
char * filev[max_redirections];
int background = 0; 

/**
 * This function splits a char* line into different tokens based on a given character
 * @return Number of tokens 
 */
int tokenizar_linea(char *linea, char *delim, char *tokens[], int max_tokens) {
    int i = 0;
    char *token = strtok(linea, delim);
    while (token != NULL && i < max_tokens - 1) {
        tokens[i++] = token;
        token = strtok(NULL, delim);
    }
    tokens[i] = NULL;
    return i;
}

/**
 * This function processes the command line to evaluate if there are redirections. 
 * If any redirection is detected, the destination file is indicated in filev[i] array.
 * filev[0] for STDIN
 * filev[1] for STDOUT
 * filev[2] for STDERR
 */
void procesar_redirecciones(char *args[]) {
    //initialization for every command
    filev[0] = NULL;
    filev[1] = NULL;
    filev[2] = NULL;
    //Store the pointer to the filename if needed.
    //args[i] set to NULL once redirection is processed
    for (int i = 0; args[i] != NULL; i++) {
        if (strcmp(args[i], "<") == 0) {
            filev[0] = args[i+1];
            args[i] = NULL;
            args[i + 1] = NULL;
        } else if (strcmp(args[i], ">") == 0) {
            filev[1] = args[i+1];
            args[i] = NULL;
            args[i + 1] = NULL;
        } else if (strcmp(args[i], "!>") == 0) {
            filev[2] = args[i+1];
            args[i] = NULL; 
            args[i + 1] = NULL;
        }
    }
}

/**
 * This function processes the input command line and returns in global variables: 
 * argvv -- command an args as argv 
 * filev -- files for redirections. NULL value means no redirection. 
 * background -- 0 means foreground; 1 background.
 */
int procesar_linea(char *linea) {
    char *comandos[max_commands];
    int num_comandos = tokenizar_linea(linea, "|", comandos, max_commands);

    //Check if background is indicated
    if (strchr(comandos[num_comandos - 1], '&')) {
        background = 1;
        char *pos = strchr(comandos[num_comandos - 1], '&'); 
        //remove character 
        *pos = '\0';
    }

    //Create pipes for interprocess communication
    int pipes[max_commands-1][2];
    for (int i = 0; i < num_comandos-1; i++) {
        if (pipe(pipes[i]) < 0) {
            perror("pipe");
            exit(1);
        }
    }

    //Finish processing
    for (int i = 0; i < num_comandos; i++) {
        int args_count = tokenizar_linea(comandos[i], " \t\n", argvv, max_args);
        procesar_redirecciones(argvv);

        /*********************** IMPLEMENT YOUR CODE FOR PROCESSES MANAGEMENT HERE ********************/
        pid_t pid = fork();
        if (pid < 0) {
            perror("fork");
            exit(1);
        }

        if (pid == 0) { // Child process
            // Input redirection first command
            if (i == 0 && filev[0]) {
                int fd = open(filev[0], O_RDONLY);
                if (fd < 0) {
                    perror("open input");
                    exit(1);
                }
                dup2(fd, STDIN_FILENO);
                close(fd);
            }

            // Output redirection ast command
            if (i == num_comandos-1 && filev[1]) {
                int fd = open(filev[1], O_WRONLY|O_CREAT|O_TRUNC, 0644);
                if (fd < 0) {
                    perror("open output");
                    exit(1);
                }
                dup2(fd, STDOUT_FILENO);
                close(fd);
            }

            // Error redirection
            if (filev[2]) {
                int fd = open(filev[2], O_WRONLY|O_CREAT|O_TRUNC, 0644);
                if (fd < 0) {
                    perror("open error");
                    exit(1);
                }
                dup2(fd, STDERR_FILENO);
                close(fd);
            }

            // Pipe handling
            if (i > 0) { // Not first command - read from previous pipe
                dup2(pipes[i-1][0], STDIN_FILENO);
            }
            if (i < num_comandos-1) { // Not last command - write to next pipe
                dup2(pipes[i][1], STDOUT_FILENO);
            }

            // Close all pipes in child
            for (int j = 0; j < num_comandos-1; j++) {
                close(pipes[j][0]);
                close(pipes[j][1]);
            }

            execvp(argvv[0], argvv);
            perror("execvp");
            exit(1);
        }
        /**********************************************************************************************/
    }

    // Close all pipes in parent
    for (int i = 0; i < num_comandos-1; i++) {
        close(pipes[i][0]);
        close(pipes[i][1]);
    }

    // Wait for children if not background
    if (!background) {
        for (int i = 0; i < num_comandos; i++) {
            wait(NULL);
        }
    }

    return num_comandos;
}

int main(int argc, char *argv[]) {

    /* STUDENTS CODE MUST BE HERE */
    if (argc != 2) {
        fprintf(stderr, "Usage: %s <script_file>\n", argv[0]);
        return 1;
    }

    int fd = open(argv[1], O_RDONLY);
    if (fd < 0) {
        perror("open");
        return 1;
    }

    char line[max_line];
    char c;
    int pos = 0;
    int first_line = 1;

    while (read(fd, &c, 1) > 0) {
        if (c == '\n') {
            line[pos] = '\0';
            pos = 0;

            if (first_line) {
                if (strcmp(line, "## Script de SSOO") != 0) {
                    fprintf(stderr, "Invalid header line\n");
                    close(fd);
                    return 1;
                }
                first_line = 0;
                continue;
            }

            if (strlen(line) > 0) {
                procesar_linea(line);
            }
        } else {
            if (pos < max_line - 1) {
                line[pos++] = c;
            }
        }
    }

    close(fd);
    return 0;
}