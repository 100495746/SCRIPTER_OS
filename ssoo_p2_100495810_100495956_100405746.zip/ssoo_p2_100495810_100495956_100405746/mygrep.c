#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>

#define MAX_LINESIZE 512

int main(int argc, char **argv) {
    
    if (argc != 3) {
        printf("Uso: %s <ruta_archivo> <cadena_busqueda>\n", argv[0]);
        return -1;
    }

    // Initial setup
    char buffer[MAX_LINESIZE];
    char *string = argv[2];  
    int matches = 0;         
    int fd = open(argv[1], O_RDONLY);
    
    // File opening error handling
    if (fd == -1) {
        perror("Error opening file");
        return -1;
    }

    // Line-by-line search implementation
    ssize_t bytes_read;
    size_t buffer_pos = 0;
    char ch;
    
    while ((bytes_read = read(fd, &ch, 1)) > 0) {
        
        if (bytes_read == -1) {
            perror("Error reading file");
            close(fd);
            return -1;
        }

        // Build line 
        if (ch != '\n' && buffer_pos < MAX_LINESIZE - 1) {
            buffer[buffer_pos++] = ch;
        } else {
            buffer[buffer_pos] = '\0'; // Finish the line
            
            // Search for string in current line
            if (strstr(buffer, string)) {
                printf("%s\n", buffer);
                matches++;
            }
            
            buffer_pos = 0; // Next line
        }
    }

    // Message if no matches found
    if (matches == 0) {
        printf("%s not found.\n", string);
    }

    close(fd);
    return 0;
}